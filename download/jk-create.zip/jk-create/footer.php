</main>

<footer class="jk-footer">
	<div class="jk-footer__in">
		<div class="jk-footer__brand">
			<a class="jk-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="jk-logo__mark" aria-hidden="true">jk</span><span class="jk-logo__name"><?php bloginfo( 'name' ); ?></span></a>
			<p><?php echo esc_html( jk_mod( 'jk_footer_text' ) ); ?></p>
		</div>
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => 'nav', 'menu_class' => 'jk-footer__menu', 'depth' => 1 ) ); ?>
		<?php endif; ?>
		<ul class="jk-footer__contacts">
			<?php if ( jk_mod( 'jk_telegram' ) ) : ?>
				<li><span>Telegram</span><a href="<?php echo esc_url( 'https://t.me/' . ltrim( jk_mod( 'jk_telegram' ), '@' ) ); ?>">@<?php echo esc_html( ltrim( jk_mod( 'jk_telegram' ), '@' ) ); ?></a></li>
			<?php endif; ?>
			<?php if ( jk_mod( 'jk_phone' ) ) : ?>
				<li><span>Телефон</span><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^\d+]/', '', jk_mod( 'jk_phone' ) ) ); ?>"><?php echo esc_html( jk_mod( 'jk_phone' ) ); ?></a></li>
			<?php endif; ?>
			<?php if ( jk_mod( 'jk_avito' ) ) : ?>
				<li><span>Авито</span><a href="<?php echo esc_url( jk_mod( 'jk_avito' ) ); ?>">Магазин на Авито</a></li>
			<?php endif; ?>
		</ul>
	</div>
	<div class="jk-footer__bottom">© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></div>
</footer>

<?php get_template_part( 'template-parts/order-modal' ); ?>
<div class="jk-toast" data-jk-toast role="status" aria-live="polite" hidden></div>
<?php wp_footer(); ?>
</body>
</html>
