<?php
/**
 * Окно заявки. Открывается любой кнопкой с data-order-open.
 */
$jk_sets = get_posts( array( 'post_type' => 'jk_set', 'numberposts' => -1, 'orderby' => 'menu_order title', 'order' => 'ASC' ) );
$jk_tg   = ltrim( jk_mod( 'jk_telegram' ), '@' );
$jk_done = isset( $_GET['ordered'] ) ? sanitize_key( wp_unslash( $_GET['ordered'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
?>
<dialog class="jk-modal" id="order" data-jk-modal <?php echo $jk_done ? 'data-open-on-load' : ''; ?>>
	<div class="jk-modal__box">
		<button class="jk-modal__close" type="button" data-modal-close aria-label="Закрыть">×</button>
		<?php if ( '1' === $jk_done ) : ?>
			<div class="jk-modal__done">
				<div class="jk-modal__icon" aria-hidden="true">✓</div>
				<h2>Заявка отправлена</h2>
				<p>Мы ответим в течение дня, подтвердим набор и цвета и пришлём ссылку на оплату.</p>
				<button class="jk-btn jk-btn--dark" type="button" data-modal-close>Хорошо</button>
			</div>
		<?php else : ?>
			<h2 class="jk-modal__title">Заказать набор</h2>
			<p class="jk-modal__lead">Оставьте контакты. Мы подтвердим набор и цвета и пришлём ссылку на оплату. Печать начинается после оплаты.</p>
			<?php if ( 'error' === $jk_done ) : ?>
				<p class="jk-modal__error">Не получилось отправить: заполните имя и контакт и попробуйте ещё раз.</p>
			<?php endif; ?>
			<form class="jk-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-tg="<?php echo esc_attr( $jk_tg ); ?>">
				<input type="hidden" name="action" value="jk_order">
				<?php wp_nonce_field( 'jk_order', 'jk_order_nonce' ); ?>
				<div class="jk-hp" aria-hidden="true"><label>Сайт <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
				<label class="jk-field"><span>Имя</span><input type="text" name="name" required autocomplete="name"></label>
				<label class="jk-field"><span>Телефон или Telegram</span><input type="text" name="contact" required placeholder="+7… или @ник"></label>
				<label class="jk-field"><span>Набор</span>
					<select name="set_id" data-order-set>
						<option value="0">Своя идея, модель под заказ</option>
						<?php foreach ( $jk_sets as $jk_s ) : ?>
							<option value="<?php echo esc_attr( $jk_s->ID ); ?>" data-schemes="<?php echo esc_attr( wp_json_encode( wp_list_pluck( jk_set_data( $jk_s )['schemes'], 'name' ) ) ); ?>"><?php echo esc_html( get_the_title( $jk_s ) . ( jk_set_data( $jk_s )['price'] ? ' · ' . jk_price( jk_set_data( $jk_s )['price'] ) : '' ) ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label class="jk-field" data-scheme-field><span>Цвета</span><select name="scheme" data-order-scheme></select></label>
				<label class="jk-field"><span>Город доставки</span><input type="text" name="city" autocomplete="address-level2"></label>
				<label class="jk-field"><span>Комментарий</span><textarea name="comment" rows="3" placeholder="Например, идея своей модели или пожелания по цветам"></textarea></label>
				<button class="jk-btn jk-btn--dark jk-btn--wide" type="submit">Отправить заявку</button>
				<?php if ( $jk_tg ) : ?>
					<p class="jk-form__alt">Или напишите сразу в Telegram: <a href="<?php echo esc_url( 'https://t.me/' . $jk_tg ); ?>">@<?php echo esc_html( $jk_tg ); ?></a></p>
				<?php endif; ?>
			</form>
		<?php endif; ?>
	</div>
</dialog>
