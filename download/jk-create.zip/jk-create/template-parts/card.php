<?php
/**
 * Карточка набора в сетке.
 */
$jk_id   = get_the_ID();
$jk      = jk_set_data( $jk_id );
$jk_cats = wp_list_pluck( $jk['categories'], 'slug' );
$jk_cat  = $jk['categories'] ? $jk['categories'][0]->name : '';
?>
<article class="jk-card"
	data-id="<?php echo esc_attr( $jk_id ); ?>"
	data-cats="<?php echo esc_attr( implode( ' ', $jk_cats ) ); ?>"
	data-level="<?php echo esc_attr( $jk['level'] ); ?>"
	data-price="<?php echo esc_attr( $jk['price'] ); ?>"
	data-order="<?php echo esc_attr( get_post_field( 'menu_order', $jk_id ) ); ?>"
	data-date="<?php echo esc_attr( get_post_time( 'U', true, $jk_id ) ); ?>"
	data-search="<?php echo esc_attr( mb_strtolower( get_the_title() . ' ' . $jk_cat . ' ' . get_the_excerpt() ) ); ?>">
	<a class="jk-card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php echo jk_card_media( $jk_id ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<span class="jk-card__badges">
			<?php if ( $jk['level'] ) : ?>
				<span class="jk-badge jk-badge--lvl-<?php echo esc_attr( $jk['level'] ); ?>"><?php echo esc_html( jk_level_label( $jk['level'] ) ); ?></span>
			<?php endif; ?>
			<?php if ( ! $jk['own'] && $jk['license'] ) : ?>
				<span class="jk-badge"><?php echo esc_html( $jk['license'] ); ?></span>
			<?php endif; ?>
		</span>
		<?php if ( $jk['price'] ) : ?>
			<span class="jk-card__price"><?php echo esc_html( jk_price( $jk['price'] ) ); ?></span>
		<?php endif; ?>
	</a>
	<button class="jk-fav" type="button" data-fav="<?php echo esc_attr( $jk_id ); ?>" aria-label="Сохранить в избранное" aria-pressed="false">
		<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 20.5s-7.5-4.6-9.3-9.2C1.4 8 3.6 4.5 7.1 4.5c2 0 3.5 1.1 4.9 2.9 1.4-1.8 2.9-2.9 4.9-2.9 3.5 0 5.7 3.5 4.4 6.8-1.8 4.6-9.3 9.2-9.3 9.2z"/></svg>
	</button>
	<a class="jk-card__meta" href="<?php the_permalink(); ?>">
		<?php echo jk_monogram( $jk_id ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<span class="jk-card__text">
			<span class="jk-card__title"><?php the_title(); ?></span>
			<span class="jk-card__sub">
				<?php
				$jk_sub = array_filter( array(
					$jk_cat,
					$jk['parts'] ? number_format( $jk['parts'], 0, ',', "\u{00A0}" ) . ' ' . jk_plural( $jk['parts'], 'деталь', 'детали', 'деталей' ) : '',
				) );
				echo esc_html( implode( ' · ', $jk_sub ) );
				?>
			</span>
		</span>
	</a>
</article>
