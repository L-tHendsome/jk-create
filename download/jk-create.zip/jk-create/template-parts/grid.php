<?php
/**
 * Сетка карточек для текущего цикла WordPress.
 */
?>
<div class="jk-grid" data-jk-grid>
	<?php
	while ( have_posts() ) :
		the_post();
		get_template_part( 'template-parts/card' );
	endwhile;
	?>
</div>
<p class="jk-empty" data-jk-empty hidden>Ничего не нашлось. Попробуйте другую категорию или <button type="button" class="jk-link" data-order-open>опишите свою идею</button>, мы сделаем модель под заказ.</p>
