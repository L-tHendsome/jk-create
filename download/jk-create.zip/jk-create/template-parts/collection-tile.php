<?php
/**
 * Плитка коллекции: три превью и название.
 */
$jk_term  = $args['term'];
$jk_items = get_posts( array(
	'post_type'   => 'jk_set',
	'numberposts' => 3,
	'orderby'     => 'menu_order',
	'order'       => 'ASC',
	'tax_query'   => array( array( 'taxonomy' => 'jk_collection', 'terms' => $jk_term->term_id ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
) );
?>
<a class="jk-coll" href="<?php echo esc_url( get_term_link( $jk_term ) ); ?>">
	<span class="jk-coll__stack">
		<?php foreach ( $jk_items as $jk_item ) : ?>
			<span class="jk-coll__shot"><?php echo jk_card_media( $jk_item->ID ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
		<?php endforeach; ?>
	</span>
	<span class="jk-coll__name"><?php echo esc_html( $jk_term->name ); ?></span>
	<span class="jk-coll__sub"><?php echo esc_html( $jk_term->count . ' ' . jk_plural( $jk_term->count, 'набор', 'набора', 'наборов' ) ); ?><?php echo $jk_term->description ? ' · ' . esc_html( $jk_term->description ) : ''; ?></span>
</a>
