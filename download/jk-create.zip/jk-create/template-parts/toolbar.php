<?php
/**
 * Фильтры над сеткой: категории чипсами, сложность и сортировка.
 * Фильтрация идёт в браузере, без перезагрузки.
 */
$jk_terms   = get_terms( array( 'taxonomy' => 'jk_category', 'hide_empty' => true ) );
$jk_current = is_tax( 'jk_category' ) ? get_queried_object()->slug : '';
?>
<div class="jk-toolbar" data-jk-toolbar>
	<div class="jk-chips" role="toolbar" aria-label="Категории">
		<button type="button" class="jk-chip<?php echo $jk_current ? '' : ' is-active'; ?>" data-cat="">Все</button>
		<?php if ( ! is_wp_error( $jk_terms ) ) : ?>
			<?php foreach ( $jk_terms as $jk_term ) : ?>
				<button type="button" class="jk-chip<?php echo $jk_current === $jk_term->slug ? ' is-active' : ''; ?>" data-cat="<?php echo esc_attr( $jk_term->slug ); ?>">
					<?php echo esc_html( $jk_term->name ); ?><span class="jk-chip__n"><?php echo esc_html( $jk_term->count ); ?></span>
				</button>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
	<div class="jk-selects">
		<label class="jk-select">
			<span class="screen-reader-text">Сложность</span>
			<select data-level-filter>
				<option value="">Любая сложность</option>
				<option value="1-2">Обычный, 1–2</option>
				<option value="3">Редкий, 3</option>
				<option value="4">Эпический, 4</option>
				<option value="5">Легендарный, 5</option>
			</select>
		</label>
		<label class="jk-select">
			<span class="screen-reader-text">Сортировка</span>
			<select data-sort>
				<option value="order">Сначала популярные</option>
				<option value="new">Сначала новые</option>
				<option value="cheap">Сначала дешевле</option>
				<option value="expensive">Сначала дороже</option>
			</select>
		</label>
	</div>
</div>
