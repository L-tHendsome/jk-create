<?php
/**
 * jk.Create — тема каталога 3D-печатных наборов в стиле Mobbin.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'JK_VERSION', '1.0.0' );
define( 'JK_DIR', get_template_directory() );
define( 'JK_URI', get_template_directory_uri() );

require JK_DIR . '/inc/content-types.php';
require JK_DIR . '/inc/meta.php';
require JK_DIR . '/inc/orders.php';
require JK_DIR . '/inc/customizer.php';
require JK_DIR . '/inc/demo.php';

add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'jk-create', JK_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 64, 'width' => 64, 'flex-width' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_image_size( 'jk-card', 640, 800, true );
	add_image_size( 'jk-shot', 900, 1125, false );
	register_nav_menus( array(
		'primary' => 'Верхнее меню',
		'footer'  => 'Меню в подвале',
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'jk-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', array(), null );
	wp_enqueue_style( 'jk-style', get_stylesheet_uri(), array( 'jk-fonts' ), JK_VERSION );
	wp_enqueue_script( 'jk-app', JK_URI . '/assets/js/app.js', array(), JK_VERSION, true );
	wp_localize_script( 'jk-app', 'jkData', array(
		'home' => home_url( '/' ),
	) );
} );

/** Цена в рублях: 24900 → «24 900 ₽». */
function jk_price( $value ) {
	$value = (int) $value;
	if ( $value <= 0 ) {
		return '';
	}
	return number_format( $value, 0, ',', "\u{00A0}" ) . "\u{00A0}₽";
}

/** Все поля набора одним массивом. */
function jk_set_data( $post = null ) {
	$post = get_post( $post );
	$get  = function ( $key ) use ( $post ) {
		return get_post_meta( $post->ID, '_jk_' . $key, true );
	};
	$cats = get_the_terms( $post, 'jk_category' );
	return array(
		'price'       => (int) $get( 'price' ),
		'parts'       => (int) $get( 'parts' ),
		'size'        => $get( 'size' ),
		'days'        => $get( 'days' ),
		'weight'      => $get( 'weight' ),
		'level'       => max( 0, min( 5, (int) $get( 'level' ) ) ),
		'license'     => $get( 'license' ),
		'author_name' => $get( 'author_name' ),
		'author_url'  => $get( 'author_url' ),
		'note'        => $get( 'note' ),
		'schemes'     => jk_parse_schemes( $get( 'schemes' ) ),
		'categories'  => ( $cats && ! is_wp_error( $cats ) ) ? $cats : array(),
		'own'         => '' === $get( 'author_name' ),
	);
}

/**
 * Цветовые схемы: по строке на схему, «Название: #aaa, #bbb, #ccc».
 */
function jk_parse_schemes( $raw ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\n/', (string) $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line || false === strpos( $line, ':' ) ) {
			continue;
		}
		list( $name, $colors ) = array_map( 'trim', explode( ':', $line, 2 ) );
		$colors = array_values( array_filter( array_map( 'sanitize_hex_color', array_map( 'trim', explode( ',', $colors ) ) ) ) );
		if ( $colors ) {
			$out[] = array( 'name' => $name, 'colors' => $colors );
		}
	}
	return $out;
}

/** Подписи сложности. */
function jk_level_label( $level ) {
	$labels = array( 1 => 'Обычный', 2 => 'Обычный', 3 => 'Редкий', 4 => 'Эпический', 5 => 'Легендарный' );
	return $labels[ $level ] ?? '';
}

/** Изображения набора: миниатюра, затем прикреплённые картинки. */
function jk_set_images( $post_id ) {
	$ids   = array();
	$thumb = get_post_thumbnail_id( $post_id );
	if ( $thumb ) {
		$ids[] = (int) $thumb;
	}
	$attached = get_attached_media( 'image', $post_id );
	uasort( $attached, function ( $a, $b ) {
		return $a->menu_order <=> $b->menu_order ?: $a->ID <=> $b->ID;
	} );
	foreach ( $attached as $att ) {
		if ( ! in_array( $att->ID, $ids, true ) ) {
			$ids[] = $att->ID;
		}
	}
	return $ids;
}

/**
 * Заглушка, пока у набора нет фото: башенки из кубиков в цветах первой схемы.
 */
function jk_placeholder_svg( $post_id, $variant = 0 ) {
	$data    = jk_set_data( $post_id );
	$colors  = $data['schemes'][ $variant % max( 1, count( $data['schemes'] ) ) ]['colors'] ?? array( '#c9c4bb', '#6f86a8', '#8a6a4f' );
	$colors  = array_pad( $colors, 3, $colors[0] );
	$seed    = crc32( get_the_title( $post_id ) ) + $variant * 7;
	$blocks  = '';
	$base_y  = 330;
	for ( $col = 0; $col < 5; $col++ ) {
		$height = 2 + ( ( $seed >> ( $col * 3 ) ) & 3 );
		$x      = 40 + $col * 44;
		for ( $row = 0; $row < $height; $row++ ) {
			$fill    = $colors[ ( $col + $row ) % 3 ];
			$y       = $base_y - ( $row + 1 ) * 34;
			$blocks .= sprintf( '<rect x="%d" y="%d" width="40" height="30" rx="5" fill="%s"/>', $x, $y, esc_attr( $fill ) );
			$blocks .= sprintf( '<circle cx="%d" cy="%d" r="5" fill="#fff" opacity=".35"/><circle cx="%d" cy="%d" r="5" fill="#fff" opacity=".35"/>', $x + 11, $y + 8, $x + 29, $y + 8 );
		}
	}
	return '<svg class="jk-ph" viewBox="0 0 300 375" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' . esc_attr( get_the_title( $post_id ) ) . '">'
		. '<rect width="300" height="375" fill="' . esc_attr( $colors[0] ) . '" opacity=".14"/>'
		. '<ellipse cx="150" cy="335" rx="125" ry="12" fill="#000" opacity=".06"/>'
		. $blocks . '</svg>';
}

/** Картинка карточки: фото или заглушка. */
function jk_card_media( $post_id, $size = 'jk-card' ) {
	$images = jk_set_images( $post_id );
	if ( $images ) {
		return wp_get_attachment_image( $images[0], $size, false, array( 'loading' => 'lazy' ) );
	}
	return jk_placeholder_svg( $post_id );
}

/** Сколько всего наборов, для подписи «N наборов». */
function jk_plural( $n, $one, $few, $many ) {
	$n10  = $n % 10;
	$n100 = $n % 100;
	if ( 1 === $n10 && 11 !== $n100 ) {
		return $one;
	}
	if ( $n10 >= 2 && $n10 <= 4 && ( $n100 < 12 || $n100 > 14 ) ) {
		return $few;
	}
	return $many;
}

/** Иконка-монограмма для карточки (как значок приложения у Mobbin). */
function jk_monogram( $post_id ) {
	$title = get_the_title( $post_id );
	$data  = jk_set_data( $post_id );
	// Самый тёмный цвет первой схемы, чтобы белая буква читалась.
	$color = '#111113';
	$best  = 1;
	foreach ( $data['schemes'][0]['colors'] ?? array() as $hex ) {
		$rgb  = sscanf( str_pad( ltrim( $hex, '#' ), 6, '0' ), '%2x%2x%2x' );
		$luma = ( 0.299 * $rgb[0] + 0.587 * $rgb[1] + 0.114 * $rgb[2] ) / 255;
		if ( $luma < $best ) {
			$best  = $luma;
			$color = $hex;
		}
	}
	$char  = mb_strtoupper( mb_substr( $title, 0, 1 ) );
	return '<span class="jk-mono" style="--mono:' . esc_attr( $color ) . '">' . esc_html( $char ) . '</span>';
}

/** Поиск по сайту ищет только наборы, если не указано иное. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	if ( $q->is_search() && empty( $q->get( 'post_type' ) ) ) {
		$q->set( 'post_type', 'jk_set' );
	}
	if ( $q->is_post_type_archive( 'jk_set' ) || $q->is_tax( array( 'jk_category', 'jk_collection' ) ) ) {
		$q->set( 'posts_per_page', 48 );
	}
} );

/** Ссылка на страницу «Избранное» (шаблон page-favorites.php). */
function jk_favorites_url() {
	$pages = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => 'page-favorites.php', 'number' => 1 ) );
	return $pages ? get_permalink( $pages[0] ) : home_url( '/' );
}

/** Страница «Избранное» создаётся при включении темы. */
add_action( 'after_switch_theme', function () {
	$pages = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => 'page-favorites.php', 'number' => 1, 'post_status' => 'publish,draft,private' ) );
	if ( $pages ) {
		return;
	}
	$id = wp_insert_post( array(
		'post_type'   => 'page',
		'post_status' => 'publish',
		'post_title'  => 'Избранное',
		'post_name'   => 'favorites',
	) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_wp_page_template', 'page-favorites.php' );
	}
} );
