<?php
/**
 * Архив наборов, категория, коллекция.
 */
get_header();

if ( is_post_type_archive( 'jk_set' ) ) {
	$jk_title = 'Все наборы';
	$jk_desc  = '';
} else {
	$jk_title = single_term_title( '', false );
	$jk_desc  = term_description();
}
global $wp_query;
$jk_total = (int) $wp_query->found_posts;
?>
<header class="jk-pagehead">
	<a class="jk-back" href="<?php echo esc_url( home_url( '/' ) ); ?>">← Все наборы</a>
	<h1><?php echo esc_html( $jk_title ); ?> <span class="jk-pagehead__n"><?php echo esc_html( $jk_total ); ?></span></h1>
	<?php if ( $jk_desc ) : ?>
		<div class="jk-pagehead__desc"><?php echo wp_kses_post( $jk_desc ); ?></div>
	<?php endif; ?>
</header>
<?php
if ( ! is_tax( 'jk_category' ) ) {
	get_template_part( 'template-parts/toolbar' );
}
if ( have_posts() ) {
	get_template_part( 'template-parts/grid' );
	the_posts_pagination( array( 'prev_text' => '←', 'next_text' => '→' ) );
} else {
	echo '<p class="jk-empty">Здесь пока пусто.</p>';
}
get_footer();
