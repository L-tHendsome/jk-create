<?php
/**
 * Страница набора: шапка как у приложения в Mobbin, лента снимков, детали, цвета.
 */
get_header();

while ( have_posts() ) :
	the_post();
	$jk_id     = get_the_ID();
	$jk        = jk_set_data( $jk_id );
	$jk_images = jk_set_images( $jk_id );
	$jk_cat    = $jk['categories'] ? $jk['categories'][0] : null;
	?>
	<article class="jk-set">
		<a class="jk-back" href="<?php echo esc_url( $jk_cat ? get_term_link( $jk_cat ) : home_url( '/' ) ); ?>">← <?php echo esc_html( $jk_cat ? $jk_cat->name : 'Все наборы' ); ?></a>

		<header class="jk-set__head">
			<?php echo jk_monogram( $jk_id ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<div class="jk-set__titles">
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
			</div>
			<div class="jk-set__buy">
				<?php if ( $jk['price'] ) : ?>
					<span class="jk-set__price"><?php echo esc_html( jk_price( $jk['price'] ) ); ?></span>
				<?php endif; ?>
				<button class="jk-btn jk-btn--ghost jk-fav-btn" type="button" data-fav="<?php echo esc_attr( $jk_id ); ?>" aria-pressed="false">
					<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 20.5s-7.5-4.6-9.3-9.2C1.4 8 3.6 4.5 7.1 4.5c2 0 3.5 1.1 4.9 2.9 1.4-1.8 2.9-2.9 4.9-2.9 3.5 0 5.7 3.5 4.4 6.8-1.8 4.6-9.3 9.2-9.3 9.2z"/></svg>
					<span data-fav-label>Сохранить</span>
				</button>
				<button class="jk-btn jk-btn--dark" type="button" data-order-open data-order-set-id="<?php echo esc_attr( $jk_id ); ?>">Заказать</button>
			</div>
		</header>

		<nav class="jk-tabs jk-tabs--left" aria-label="Разделы набора">
			<a class="jk-tab is-active" href="#shots">Фото</a>
			<a class="jk-tab" href="#details">Детали</a>
			<?php if ( $jk['schemes'] ) : ?>
				<a class="jk-tab" href="#colors">Цвета</a>
			<?php endif; ?>
		</nav>

		<section id="shots" class="jk-shots" data-jk-shots>
			<?php if ( $jk_images ) : ?>
				<?php foreach ( $jk_images as $jk_img ) : ?>
					<button class="jk-shot" type="button" data-full="<?php echo esc_url( wp_get_attachment_image_url( $jk_img, 'full' ) ); ?>">
						<?php echo wp_get_attachment_image( $jk_img, 'jk-shot', false, array( 'loading' => 'lazy' ) ); ?>
					</button>
				<?php endforeach; ?>
			<?php else : ?>
				<?php for ( $jk_v = 0; $jk_v < max( 1, count( $jk['schemes'] ) ); $jk_v++ ) : ?>
					<div class="jk-shot jk-shot--ph">
						<?php echo jk_placeholder_svg( $jk_id, $jk_v ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php if ( isset( $jk['schemes'][ $jk_v ] ) ) : ?>
							<span class="jk-shot__cap"><?php echo esc_html( $jk['schemes'][ $jk_v ]['name'] ); ?></span>
						<?php endif; ?>
					</div>
				<?php endfor; ?>
			<?php endif; ?>
		</section>

		<div class="jk-set__body">
			<section id="details" class="jk-details">
				<h2>Детали</h2>
				<dl class="jk-stats">
					<?php
					$jk_stats = array(
						'Деталей'     => $jk['parts'] ? number_format( $jk['parts'], 0, ',', "\u{00A0}" ) : '',
						'Размер'      => $jk['size'],
						'Пластик'     => $jk['weight'],
						'Изготовление'=> $jk['days'],
						'Сложность'   => $jk['level'] ? $jk['level'] . ' из 5 · ' . jk_level_label( $jk['level'] ) : '',
						'Категория'   => $jk_cat ? $jk_cat->name : '',
					);
					foreach ( array_filter( $jk_stats ) as $jk_label => $jk_value ) :
						?>
						<div><dt><?php echo esc_html( $jk_label ); ?></dt><dd><?php echo esc_html( $jk_value ); ?></dd></div>
					<?php endforeach; ?>
				</dl>
				<?php if ( $jk['note'] ) : ?>
					<p class="jk-note"><?php echo esc_html( $jk['note'] ); ?></p>
				<?php endif; ?>
				<div class="jk-content"><?php the_content(); ?></div>
			</section>

			<aside class="jk-aside">
				<?php if ( $jk['own'] ) : ?>
					<div class="jk-box">
						<h3>Авторская модель jk.Create</h3>
						<p>Мы спроектировали её с нуля. Файлы не продаются и не выкладываются в открытый доступ. В комплекте инструкция, номерная табличка и сертификат.</p>
					</div>
				<?php else : ?>
					<div class="jk-box">
						<h3>Модель другого автора</h3>
						<p>Печатаем по лицензии <?php echo esc_html( $jk['license'] ); ?>, которая разрешает продажу.
						Автор: <?php if ( $jk['author_url'] ) : ?><a href="<?php echo esc_url( $jk['author_url'] ); ?>" rel="noopener" target="_blank"><?php echo esc_html( $jk['author_name'] ); ?></a><?php else : ?><?php echo esc_html( $jk['author_name'] ); ?><?php endif; ?>.</p>
					</div>
				<?php endif; ?>
				<div class="jk-box">
					<h3>Как заказать</h3>
					<ol class="jk-steps">
						<li>Оставьте заявку и выберите цвета</li>
						<li>Оплатите по ссылке картой или СБП</li>
						<li>Печатаем <?php echo esc_html( $jk['days'] ? $jk['days'] : '7–14 дней' ); ?></li>
						<li>Отправляем СДЭК, Почтой или Авито Доставкой</li>
					</ol>
				</div>
			</aside>
		</div>

		<?php if ( $jk['schemes'] ) : ?>
			<section id="colors" class="jk-colors">
				<h2>Цвета</h2>
				<div class="jk-schemes">
					<?php foreach ( $jk['schemes'] as $jk_scheme ) : ?>
						<button class="jk-scheme" type="button" data-order-open data-order-set-id="<?php echo esc_attr( $jk_id ); ?>" data-order-scheme-name="<?php echo esc_attr( $jk_scheme['name'] ); ?>">
							<span class="jk-swatches">
								<?php foreach ( $jk_scheme['colors'] as $jk_c ) : ?>
									<span style="background:<?php echo esc_attr( $jk_c ); ?>"></span>
								<?php endforeach; ?>
							</span>
							<span class="jk-scheme__name"><?php echo esc_html( $jk_scheme['name'] ); ?></span>
							<span class="jk-scheme__go">Заказать в этих цветах →</span>
						</button>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endif; ?>

		<?php
		$jk_related = new WP_Query( array(
			'post_type'      => 'jk_set',
			'posts_per_page' => 4,
			'post__not_in'   => array( $jk_id ),
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
		) );
		if ( $jk_related->have_posts() ) :
			?>
			<section class="jk-related">
				<h2>Ещё наборы</h2>
				<div class="jk-grid">
					<?php
					while ( $jk_related->have_posts() ) :
						$jk_related->the_post();
						get_template_part( 'template-parts/card' );
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			</section>
		<?php endif; ?>
	</article>
	<?php
endwhile;
?>
<div class="jk-lightbox" data-jk-lightbox hidden><button type="button" class="jk-modal__close" data-lightbox-close aria-label="Закрыть">×</button><img alt=""></div>
<?php
get_footer();
