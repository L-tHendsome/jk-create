<?php
/**
 * Template Name: Избранное
 * Наборы, отмеченные сердечком. Список хранится в браузере посетителя.
 */
get_header();
$jk_sets = new WP_Query( array( 'post_type' => 'jk_set', 'posts_per_page' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
?>
<header class="jk-pagehead">
	<a class="jk-back" href="<?php echo esc_url( home_url( '/' ) ); ?>">← Все наборы</a>
	<h1><?php the_title(); ?> <span class="jk-pagehead__n" data-fav-count-inline>0</span></h1>
</header>
<div class="jk-grid" data-jk-grid data-favorites-only>
	<?php
	while ( $jk_sets->have_posts() ) :
		$jk_sets->the_post();
		get_template_part( 'template-parts/card' );
	endwhile;
	wp_reset_postdata();
	?>
</div>
<p class="jk-empty" data-jk-empty hidden>Здесь появятся наборы, которые вы отметите сердечком. <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Открыть каталог</a></p>
<?php
get_footer();
