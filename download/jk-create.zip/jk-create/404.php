<?php
get_header();
?>
<div class="jk-page jk-404">
	<h1>Страница не найдена</h1>
	<p>Возможно, набор переименовали или убрали из каталога.</p>
	<a class="jk-btn jk-btn--dark" href="<?php echo esc_url( home_url( '/' ) ); ?>">Открыть каталог</a>
</div>
<?php
get_footer();
