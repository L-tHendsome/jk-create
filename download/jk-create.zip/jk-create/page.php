<?php
/**
 * Обычная страница.
 */
get_header();
while ( have_posts() ) :
	the_post();
	?>
	<article class="jk-page">
		<h1><?php the_title(); ?></h1>
		<div class="jk-content"><?php the_content(); ?></div>
	</article>
	<?php
endwhile;
get_footer();
