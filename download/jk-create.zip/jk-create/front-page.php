<?php
/**
 * Главная: поиск, вкладки «Наборы / Коллекции», сетка карточек.
 */
get_header();

$jk_sets  = new WP_Query( array(
	'post_type'      => 'jk_set',
	'posts_per_page' => -1,
	'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
) );
$jk_total = (int) $jk_sets->found_posts;
$jk_cols  = get_terms( array( 'taxonomy' => 'jk_collection', 'hide_empty' => true ) );
?>
<section class="jk-hero">
	<h1 class="jk-hero__title"><?php echo esc_html( jk_mod( 'jk_hero_title' ) ); ?></h1>
	<p class="jk-hero__text"><?php echo esc_html( jk_mod( 'jk_hero_text' ) ); ?></p>
	<form class="jk-search jk-search--big" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
		<label class="screen-reader-text" for="jk-q-big">Поиск наборов</label>
		<input id="jk-q-big" type="search" name="s" placeholder="Найдите набор среди <?php echo esc_attr( $jk_total . ' ' . jk_plural( $jk_total, 'модели', 'моделей', 'моделей' ) ); ?>" autocomplete="off" data-jk-search>
		<input type="hidden" name="post_type" value="jk_set">
	</form>
	<ul class="jk-facts">
		<li><strong>Без клея</strong> детали на защёлках и штифтах</li>
		<li><strong>7–14 дней</strong> печать под заказ</li>
		<li><strong>Сертификат</strong> и номерная табличка</li>
	</ul>
</section>

<div class="jk-tabs" role="tablist" aria-label="Что показать">
	<button class="jk-tab is-active" type="button" role="tab" aria-selected="true" data-tab="sets">Наборы <span><?php echo esc_html( $jk_total ); ?></span></button>
	<?php if ( $jk_cols && ! is_wp_error( $jk_cols ) ) : ?>
		<button class="jk-tab" type="button" role="tab" aria-selected="false" data-tab="collections" id="collections">Коллекции <span><?php echo esc_html( count( $jk_cols ) ); ?></span></button>
	<?php endif; ?>
</div>

<section class="jk-pane" data-pane="sets">
	<?php get_template_part( 'template-parts/toolbar' ); ?>
	<?php
	if ( $jk_sets->have_posts() ) {
		echo '<div class="jk-grid" data-jk-grid>';
		while ( $jk_sets->have_posts() ) {
			$jk_sets->the_post();
			get_template_part( 'template-parts/card' );
		}
		echo '</div>';
		wp_reset_postdata();
		echo '<p class="jk-empty" data-jk-empty hidden>Ничего не нашлось. Попробуйте другую категорию или <button type="button" class="jk-link" data-order-open data-order-idea>опишите свою идею</button>, мы сделаем модель под заказ.</p>';
	} else {
		echo '<p class="jk-empty">Наборов пока нет. Добавьте их в админке: «Наборы» → «Добавить набор».</p>';
	}
	?>
</section>

<?php if ( $jk_cols && ! is_wp_error( $jk_cols ) ) : ?>
	<section class="jk-pane" data-pane="collections" hidden>
		<div class="jk-collections">
			<?php foreach ( $jk_cols as $jk_col ) : ?>
				<?php get_template_part( 'template-parts/collection-tile', null, array( 'term' => $jk_col ) ); ?>
			<?php endforeach; ?>
		</div>
	</section>
<?php endif; ?>

<section class="jk-cta">
	<div>
		<h2>Сделаем модель по вашей идее</h2>
		<p>Дракон над сокровищами, ваш дом в виде таверны или замок для настольной игры. Опишите идею, мы покажем 3D-визуализацию и назовём цену и срок.</p>
	</div>
	<button class="jk-btn jk-btn--light" type="button" data-order-open data-order-idea>Описать идею</button>
</section>
<?php
get_footer();
