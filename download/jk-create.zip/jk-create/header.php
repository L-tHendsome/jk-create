<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text jk-skip" href="#content">К содержимому</a>
<header class="jk-header">
	<div class="jk-header__in">
		<a class="jk-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php if ( has_custom_logo() ) : ?>
				<?php echo wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'thumbnail', false, array( 'class' => 'jk-logo__img' ) ); ?>
			<?php else : ?>
				<span class="jk-logo__mark" aria-hidden="true">jk</span>
			<?php endif; ?>
			<span class="jk-logo__name"><?php bloginfo( 'name' ); ?></span>
		</a>

		<nav class="jk-nav" aria-label="Главное меню">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'jk-nav__list', 'depth' => 1 ) );
			} else {
				?>
				<ul class="jk-nav__list">
					<li class="<?php echo is_front_page() || is_post_type_archive( 'jk_set' ) || is_singular( 'jk_set' ) ? 'current-menu-item' : ''; ?>"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Наборы</a></li>
					<li class="<?php echo is_tax( 'jk_collection' ) ? 'current-menu-item' : ''; ?>"><a href="<?php echo esc_url( home_url( '/#collections' ) ); ?>">Коллекции</a></li>
					<li><a href="#order" data-order-open data-order-idea>Под заказ</a></li>
				</ul>
				<?php
			}
			?>
		</nav>

		<form class="jk-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
			<label class="screen-reader-text" for="jk-q">Поиск наборов</label>
			<input id="jk-q" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="Замок, корабль, марбл-ран…" autocomplete="off" data-jk-search>
			<input type="hidden" name="post_type" value="jk_set">
			<kbd class="jk-kbd" aria-hidden="true">/</kbd>
		</form>

		<div class="jk-actions">
			<a class="jk-iconbtn" href="<?php echo esc_url( jk_favorites_url() ); ?>" aria-label="Избранное">
				<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.5s-7.5-4.6-9.3-9.2C1.4 8 3.6 4.5 7.1 4.5c2 0 3.5 1.1 4.9 2.9 1.4-1.8 2.9-2.9 4.9-2.9 3.5 0 5.7 3.5 4.4 6.8-1.8 4.6-9.3 9.2-9.3 9.2z"/></svg>
				<span class="jk-count" data-fav-count hidden>0</span>
			</a>
			<button class="jk-btn jk-btn--dark" type="button" data-order-open>Заказать</button>
		</div>
	</div>
</header>
<main id="content" class="jk-main">
