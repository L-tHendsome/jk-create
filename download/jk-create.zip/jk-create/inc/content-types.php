<?php
/**
 * Наборы, категории и коллекции.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_post_type( 'jk_set', array(
		'labels'       => array(
			'name'          => 'Наборы',
			'singular_name' => 'Набор',
			'add_new'       => 'Добавить набор',
			'add_new_item'  => 'Новый набор',
			'edit_item'     => 'Редактировать набор',
			'all_items'     => 'Все наборы',
			'search_items'  => 'Найти набор',
			'not_found'     => 'Наборов нет',
		),
		'public'       => true,
		'has_archive'  => 'sets',
		'rewrite'      => array( 'slug' => 'set' ),
		'menu_icon'    => 'dashicons-screenoptions',
		'menu_position'=> 5,
		'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
		'show_in_rest' => true,
	) );

	register_taxonomy( 'jk_category', 'jk_set', array(
		'labels'            => array(
			'name'          => 'Категории',
			'singular_name' => 'Категория',
			'add_new_item'  => 'Новая категория',
		),
		'hierarchical'      => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'category-set' ),
	) );

	register_taxonomy( 'jk_collection', 'jk_set', array(
		'labels'            => array(
			'name'          => 'Коллекции',
			'singular_name' => 'Коллекция',
			'add_new_item'  => 'Новая коллекция',
		),
		'hierarchical'      => false,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'collection' ),
	) );
} );

add_action( 'after_switch_theme', function () {
	flush_rewrite_rules();
} );

/** Колонки цены и сложности в списке наборов. */
add_filter( 'manage_jk_set_posts_columns', function ( $cols ) {
	$cols['jk_price'] = 'Цена';
	$cols['jk_level'] = 'Сложность';
	return $cols;
} );

add_action( 'manage_jk_set_posts_custom_column', function ( $col, $post_id ) {
	if ( 'jk_price' === $col ) {
		echo esc_html( jk_price( get_post_meta( $post_id, '_jk_price', true ) ) );
	}
	if ( 'jk_level' === $col ) {
		$level = (int) get_post_meta( $post_id, '_jk_level', true );
		echo esc_html( $level ? str_repeat( '●', $level ) . str_repeat( '○', 5 - $level ) : '—' );
	}
}, 10, 2 );
