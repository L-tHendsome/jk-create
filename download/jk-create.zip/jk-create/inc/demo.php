<?php
/**
 * Демо-наборы: создаются один раз при включении темы, если наборов ещё нет.
 * Их можно спокойно редактировать или удалять.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function jk_demo_sets() {
	return array(
		array(
			'title' => 'Цитадель', 'slug' => 'citadel', 'cat' => 'Замки и крепости', 'col' => array( 'Фэнтези-мир' ),
			'desc'  => 'Замок с четырьмя башнями, воротами и внутренним двором. Секции стен переставляются.',
			'meta'  => array( 'price' => 33900, 'parts' => 1240, 'size' => '48×48×36 см', 'days' => '14 дней', 'level' => 5,
				'schemes' => "Камень и лазурь: #b9b4aa, #3f6fa8, #8a6a4f\nПесчаник и багрянец: #d9c7a3, #a63d32, #5a3d2b\nТёмный камень и золото: #5b5f66, #6b4c9a, #c9a24a" ),
		),
		array(
			'title' => 'Таверна', 'slug' => 'tavern', 'cat' => 'Таверны и дома', 'col' => array( 'Фэнтези-мир' ),
			'desc'  => 'Двухэтажная таверна с фахверком, вывеской, трубой и бочками у входа. Крыша снимается.',
			'meta'  => array( 'price' => 24900, 'parts' => 860, 'size' => '40×30×34 см', 'days' => '10–14 дней', 'level' => 4,
				'schemes' => "Черепица: #e8dcc4, #b5452f, #5a3d2b\nСланец: #b9b4aa, #3f6fa8, #8a6a4f\nМох: #d9c7a3, #5f8a4a, #5a3d2b" ),
		),
		array(
			'title' => 'Пиратский бриг', 'slug' => 'pirate-brig', 'cat' => 'Корабли', 'col' => array( 'Фэнтези-мир', 'Морское' ),
			'desc'  => 'Двухмачтовый корабль на подставке: паруса, пушки, кормовой фонарь и флаг.',
			'meta'  => array( 'price' => 19900, 'parts' => 620, 'size' => '58×18×46 см', 'days' => '10–12 дней', 'level' => 3,
				'schemes' => "Классика: #8a6a4f, #efe6d2, #c9a24a\nЧёрные паруса: #2a2a2c, #5b5f66, #a63d32\nМорская волна: #2f8a8a, #efe6d2, #c9a24a" ),
		),
		array(
			'title' => 'Башня мага', 'slug' => 'mage-tower', 'cat' => 'Замки и крепости', 'col' => array( 'Фэнтези-мир' ),
			'desc'  => 'Каменная башня с балконом, остроконечной крышей и светящимся кристаллом на шпиле.',
			'meta'  => array( 'price' => 14900, 'parts' => 380, 'size' => '18×18×52 см', 'days' => '7–10 дней', 'level' => 2,
				'schemes' => "Аметист: #b9b4aa, #6b4c9a, #c9a24a\nЛазурь: #e8dcc4, #3f6fa8, #c9a24a\nИзумруд: #5b5f66, #2f8a8a, #b87333" ),
		),
		array(
			'title' => 'Сундук-мимик', 'slug' => 'mimic-chest', 'cat' => 'Сундуки и мелочи', 'col' => array( 'Фэнтези-мир', 'Собрать за вечер' ),
			'desc'  => 'Сундук, который кусается: открывается крышка, внутри зубы, язык и золотые монеты. Собирается за вечер.',
			'meta'  => array( 'price' => 8900, 'parts' => 150, 'size' => '16×12×14 см', 'days' => '7 дней', 'level' => 1,
				'schemes' => "Дуб и золото: #8a6a4f, #c9a24a, #a63d32\nЭбеновое дерево: #2a2a2c, #c9a24a, #6b4c9a\nБерёза: #e8dcc4, #b87333, #a63d32" ),
		),
		array(
			'title' => 'Магнитный марбл-ран', 'slug' => 'marble-run', 'cat' => 'Марбл-раны', 'col' => array( 'Для инженеров' ), 'image' => 'marble.webp',
			'desc'  => 'Трасса для шариков на магнитах: желоба, спуски, петля и водоворот крепятся на любую стальную поверхность. 44 детали.',
			'meta'  => array( 'price' => 8300, 'parts' => 44, 'weight' => '485 г', 'size' => 'модульный', 'days' => '7–10 дней', 'level' => 2,
				'author_name' => 'Jan Pieper', 'author_url' => 'https://github.com/jhpieper/marble-run', 'license' => 'MIT', 'note' => 'Магниты 10×2 мм не входят',
				'schemes' => "Радуга: #e2513b, #f2b632, #3f6fa8\nМонохром: #2a2a2c, #efefef, #8c8c8c" ),
		),
		array(
			'title' => 'Dummy 13', 'slug' => 'dummy-13', 'cat' => 'Фигурки', 'col' => array( 'Собрать за вечер' ),
			'desc'  => 'Шарнирная фигурка на 13 суставах: поза держится, детали щёлкают на шарах. Отличная база для покраски и кастома.',
			'meta'  => array( 'price' => 600, 'weight' => '33 г', 'size' => '13 см', 'days' => '3–5 дней', 'level' => 1,
				'author_name' => 'Lucky 13 Toys', 'author_url' => 'https://makerworld.com/', 'license' => 'CC BY 4.0', 'note' => 'Вес и время по данным автора',
				'schemes' => "Графит: #3a3a3c, #5b5f66, #e2513b\nКость: #efe6d2, #b9b4aa, #3f6fa8" ),
		),
		array(
			'title' => 'Манипулятор Moveo', 'slug' => 'moveo', 'cat' => 'Механизмы', 'col' => array( 'Для инженеров' ), 'image' => 'moveo.webp',
			'desc'  => 'Пятиосевая роборука BCN3D Moveo: корпус, редукторы и захват. Электроника и моторы ставятся отдельно.',
			'meta'  => array( 'price' => 64600, 'parts' => 32, 'weight' => '3 810 г', 'size' => 'высота ≈ 60 см', 'days' => '14–21 день', 'level' => 5,
				'author_name' => 'BCN3D Technologies', 'author_url' => 'https://github.com/BCN3D/BCN3D-Moveo', 'license' => 'MIT', 'note' => 'Моторы и электроника не входят',
				'schemes' => "Инженерный: #efefef, #2a2a2c, #e2513b\nСиний: #3f6fa8, #efefef, #2a2a2c" ),
		),
	);
}

/** Латинские адреса для демо-категорий и коллекций. */
function jk_demo_terms() {
	return array(
		'jk_category'   => array(
			'Замки и крепости' => 'castles',
			'Таверны и дома'   => 'houses',
			'Корабли'          => 'ships',
			'Сундуки и мелочи' => 'chests',
			'Марбл-раны'       => 'marble-runs',
			'Фигурки'          => 'figures',
			'Механизмы'        => 'mechanisms',
		),
		'jk_collection' => array(
			'Фэнтези-мир'      => 'fantasy',
			'Морское'          => 'sea',
			'Собрать за вечер' => 'one-evening',
			'Для инженеров'    => 'engineers',
		),
	);
}

function jk_seed_demo() {
	if ( get_option( 'jk_demo_seeded' ) ) {
		return;
	}
	$existing = get_posts( array( 'post_type' => 'jk_set', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids' ) );
	update_option( 'jk_demo_seeded', 1 );
	if ( $existing ) {
		return;
	}

	foreach ( jk_demo_terms() as $tax => $terms ) {
		foreach ( $terms as $name => $slug ) {
			if ( ! term_exists( $name, $tax ) ) {
				wp_insert_term( $name, $tax, array( 'slug' => $slug ) );
			}
		}
	}

	$order = 0;
	foreach ( jk_demo_sets() as $set ) {
		$post_id = wp_insert_post( array(
			'post_type'    => 'jk_set',
			'post_status'  => 'publish',
			'post_title'   => $set['title'],
			'post_name'    => $set['slug'],
			'post_excerpt' => $set['desc'],
			'post_content' => '<!-- wp:paragraph --><p>' . esc_html( $set['desc'] ) . '</p><!-- /wp:paragraph -->',
			'menu_order'   => $order++,
		) );
		if ( ! $post_id || is_wp_error( $post_id ) ) {
			continue;
		}
		foreach ( $set['meta'] as $k => $v ) {
			update_post_meta( $post_id, '_jk_' . $k, $v );
		}
		wp_set_object_terms( $post_id, $set['cat'], 'jk_category' );
		wp_set_object_terms( $post_id, $set['col'], 'jk_collection' );
		if ( ! empty( $set['image'] ) ) {
			jk_demo_attach_image( $post_id, $set['image'] );
		}
	}
}
add_action( 'after_switch_theme', 'jk_seed_demo', 20 );

function jk_demo_attach_image( $post_id, $file ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$source = JK_DIR . '/assets/img/' . $file;
	if ( ! file_exists( $source ) ) {
		return;
	}
	$tmp = wp_tempnam( $file );
	copy( $source, $tmp );
	$id = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), $post_id );
	if ( is_wp_error( $id ) ) {
		@unlink( $tmp ); // phpcs:ignore
		return;
	}
	set_post_thumbnail( $post_id, $id );
}
