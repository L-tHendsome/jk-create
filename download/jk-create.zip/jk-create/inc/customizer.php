<?php
/**
 * Внешний вид → Настроить → jk.Create: тексты главной и контакты.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function jk_mod_defaults() {
	return array(
		'jk_hero_title'  => 'Наборы, которые печатают для вас',
		'jk_hero_text'   => 'Замки, таверны, корабли и механизмы для сборки без клея. Выберите набор и цвета, и мы напечатаем его за 7–14 дней.',
		'jk_telegram'    => 'jkcreate',
		'jk_phone'       => '+7 (900) 000-00-00',
		'jk_avito'       => '',
		'jk_order_email' => get_option( 'admin_email' ),
		'jk_footer_text' => 'Авторские 3D-печатные наборы · 14+ · Разработано и изготовлено в России',
	);
}

function jk_mod( $key ) {
	$defaults = jk_mod_defaults();
	return get_theme_mod( $key, $defaults[ $key ] ?? '' );
}

add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_section( 'jk_section', array(
		'title'    => 'jk.Create',
		'priority' => 30,
	) );
	$fields = array(
		'jk_hero_title'  => array( 'Заголовок на главной', 'text', 'sanitize_text_field' ),
		'jk_hero_text'   => array( 'Подзаголовок на главной', 'textarea', 'sanitize_textarea_field' ),
		'jk_telegram'    => array( 'Telegram (без @)', 'text', 'sanitize_text_field' ),
		'jk_phone'       => array( 'Телефон', 'text', 'sanitize_text_field' ),
		'jk_avito'       => array( 'Ссылка на Авито', 'url', 'esc_url_raw' ),
		'jk_order_email' => array( 'Почта для заявок', 'email', 'sanitize_email' ),
		'jk_footer_text' => array( 'Текст в подвале', 'text', 'sanitize_text_field' ),
	);
	$defaults = jk_mod_defaults();
	foreach ( $fields as $id => $f ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $defaults[ $id ],
			'sanitize_callback' => $f[2],
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $f[0],
			'section' => 'jk_section',
			'type'    => $f[1],
		) );
	}
} );
