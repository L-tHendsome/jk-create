<?php
/**
 * Заявки: форма на сайте → запись «Заявка» в админке + письмо владельцу.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_post_type( 'jk_order', array(
		'labels'          => array(
			'name'          => 'Заявки',
			'singular_name' => 'Заявка',
			'all_items'     => 'Все заявки',
			'edit_item'     => 'Заявка',
			'not_found'     => 'Заявок пока нет',
		),
		'public'          => false,
		'show_ui'         => true,
		'menu_icon'       => 'dashicons-email-alt',
		'menu_position'   => 6,
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
		'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap'    => true,
	) );
} );

add_action( 'admin_post_nopriv_jk_order', 'jk_handle_order' );
add_action( 'admin_post_jk_order', 'jk_handle_order' );

function jk_handle_order() {
	$back = wp_get_referer() ? wp_get_referer() : home_url( '/' );
	$back = remove_query_arg( 'ordered', $back );

	if ( ! isset( $_POST['jk_order_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['jk_order_nonce'] ) ), 'jk_order' ) ) {
		wp_safe_redirect( add_query_arg( 'ordered', 'error', $back ) );
		exit;
	}
	// Ловушка для ботов: настоящий посетитель это поле не видит.
	if ( ! empty( $_POST['website'] ) ) {
		wp_safe_redirect( add_query_arg( 'ordered', '1', $back ) );
		exit;
	}

	$field = function ( $key ) {
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	};
	$name    = $field( 'name' );
	$contact = $field( 'contact' );
	$set_id  = isset( $_POST['set_id'] ) ? absint( $_POST['set_id'] ) : 0;
	$scheme  = $field( 'scheme' );
	$city    = $field( 'city' );
	$comment = isset( $_POST['comment'] ) ? sanitize_textarea_field( wp_unslash( $_POST['comment'] ) ) : '';

	if ( '' === $name || '' === $contact ) {
		wp_safe_redirect( add_query_arg( 'ordered', 'error', $back ) );
		exit;
	}

	$set_title = $set_id && 'jk_set' === get_post_type( $set_id ) ? get_the_title( $set_id ) : 'Своя идея';
	$lines     = array(
		'Имя: ' . $name,
		'Контакт: ' . $contact,
		'Набор: ' . $set_title,
		'Цвета: ' . ( $scheme ? $scheme : '—' ),
		'Город: ' . ( $city ? $city : '—' ),
		'Комментарий: ' . ( $comment ? $comment : '—' ),
	);
	$body = implode( "\n", $lines );

	wp_insert_post( array(
		'post_type'    => 'jk_order',
		'post_status'  => 'private',
		'post_title'   => $set_title . ' · ' . $name,
		'post_content' => $body,
	) );

	$to = get_theme_mod( 'jk_order_email', get_option( 'admin_email' ) );
	wp_mail( $to, 'Новая заявка: ' . $set_title, $body );

	wp_safe_redirect( add_query_arg( 'ordered', '1', $back ) . '#order' );
	exit;
}
