<?php
/**
 * Поля набора в админке.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function jk_meta_fields() {
	return array(
		'price'       => array( 'Цена, ₽', 'number', '24900' ),
		'parts'       => array( 'Деталей', 'number', '860' ),
		'size'        => array( 'Размер', 'text', '40×30×34 см' ),
		'weight'      => array( 'Пластик', 'text', '485 г' ),
		'days'        => array( 'Срок изготовления', 'text', '10–14 дней' ),
		'level'       => array( 'Сложность сборки, 1–5', 'number', '3' ),
		'schemes'     => array( 'Цветовые схемы (по строке: «Название: #hex, #hex, #hex»)', 'textarea', "Черепица: #e8dcc4, #b5452f, #5a3d2b\nСланец: #9aa1a6, #3f6fa8, #8a6a4f" ),
		'author_name' => array( 'Автор модели (пусто, если модель наша)', 'text', 'Jan Pieper' ),
		'author_url'  => array( 'Ссылка на модель автора', 'url', 'https://github.com/…' ),
		'license'     => array( 'Лицензия', 'text', 'MIT' ),
		'note'        => array( 'Примечание к цене', 'text', 'Магниты не входят' ),
	);
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'jk_set_meta', 'Параметры набора', 'jk_render_meta_box', 'jk_set', 'normal', 'high' );
} );

function jk_render_meta_box( $post ) {
	wp_nonce_field( 'jk_save_meta', 'jk_meta_nonce' );
	echo '<p style="color:#646970">Фото: задайте миниатюру записи и загрузите остальные снимки в медиатеку через этот набор, они появятся в галерее по порядку.</p>';
	echo '<table class="form-table"><tbody>';
	foreach ( jk_meta_fields() as $key => $field ) {
		list( $label, $type, $placeholder ) = $field;
		$value = get_post_meta( $post->ID, '_jk_' . $key, true );
		$id    = 'jk_' . $key;
		echo '<tr><th><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'textarea' === $type ) {
			echo '<textarea class="large-text" rows="4" id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" placeholder="' . esc_attr( $placeholder ) . '">' . esc_textarea( $value ) . '</textarea>';
		} else {
			echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr( $placeholder ) . '">';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}

add_action( 'save_post_jk_set', function ( $post_id ) {
	if ( ! isset( $_POST['jk_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['jk_meta_nonce'] ) ), 'jk_save_meta' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( jk_meta_fields() as $key => $field ) {
		$name = 'jk_' . $key;
		if ( ! isset( $_POST[ $name ] ) ) {
			continue;
		}
		$raw = wp_unslash( $_POST[ $name ] );
		switch ( $field[1] ) {
			case 'number':
				$value = '' === $raw ? '' : absint( $raw );
				break;
			case 'url':
				$value = esc_url_raw( $raw );
				break;
			case 'textarea':
				$value = sanitize_textarea_field( $raw );
				break;
			default:
				$value = sanitize_text_field( $raw );
		}
		update_post_meta( $post_id, '_jk_' . $key, $value );
	}
} );
