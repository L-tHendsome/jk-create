<?php
/**
 * Запасной шаблон.
 */
get_header();
?>
<div class="jk-page">
	<?php if ( have_posts() ) : ?>
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article class="jk-post">
				<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				<?php the_excerpt(); ?>
			</article>
		<?php endwhile; ?>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p>Записей нет.</p>
	<?php endif; ?>
</div>
<?php
get_footer();
